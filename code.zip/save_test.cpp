// save_test.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <mysql.h>
#include <iomanip>
#include <fstream>

using namespace std;

int main()
{
	MYSQL *conn=NULL, *conn1 = NULL;
	MYSQL_ROW row;
	MYSQL_RES* res=NULL;
	conn = mysql_init(0);
	conn1 = mysql_init(0);
	const char separator = ' ';

	/*RULE 1*/
	conn = mysql_real_connect(conn, "localhost", "root", "romita", "save_test_db", 3306, NULL, TRUE);
	if (conn) {
			if (!mysql_query(conn, "CALL `save_test_db`.`rule_1`()"))
			{
				cout << "Rule 1" << endl;
				ofstream outfile("rule_1.txt", ios::out);
				res = mysql_use_result(conn);
				cout << setw(115) << setfill('-')<<" "<<endl;
				cout << left << setw(20) << setfill(separator) << "Name";
				outfile << left << setw(20) << setfill(separator) << "Name";
				cout << left << setw(15) << setfill(separator) << "Account Number";
				outfile << left << setw(15) << setfill(separator) << "Account Number";
				cout << left << setw(20) << setfill(separator) << "Transaction Number";
				outfile << left << setw(20) << setfill(separator) << "Transaction Number";
				cout << left << setw(40) << setfill(separator) << "Merchant";
				outfile << left << setw(40) << setfill(separator) << "Merchant";
				cout << left << setw(15) << setfill(separator) << "Transaction Amount" << endl;
				outfile << left << setw(15) << setfill(separator) << "Transaction Amount" << endl;
				while ((row = mysql_fetch_row(res)) != NULL)
				{
					cout << left << setw(20) << setfill(separator) << row[4];
					outfile << left << setw(20) << setfill(separator) << row[4];
					cout << left << setw(15) << setfill(separator) << row[0];
					outfile << left << setw(15) << setfill(separator) << row[0];
					cout << left << setw(20) << setfill(separator) << row[2];
					outfile << left << setw(20) << setfill(separator) << row[2];
					cout << left << setw(40) << setfill(separator) << row[3];
					outfile << left << setw(40) << setfill(separator) << row[3];
					cout << left << setw(15) << setfill(separator) << row[1] << endl;
					outfile << left << setw(15) << setfill(separator) << row[1] << endl;
				}
			}
			else
			{
				cout << "Query failed: " << mysql_error(conn) << endl;
			}

			mysql_free_result(res);
			mysql_close(conn);
	}
	else {
		puts("Connection to database has failed!");
	}	
	cout << endl << endl;

	/*RULE 2*/
	conn1 = mysql_real_connect(conn1, "localhost", "root", "romita", "save_test_db", 3306, NULL, 0);
	if (conn1) {
		if(!mysql_query(conn1, "CALL `save_test_db`.`rule_2`()"))
		{
			cout <<endl<< "Rule 2" << endl;
			ofstream outfile1("rule_2.txt", ios::out);
			res = mysql_use_result(conn1);
			cout << setw(115) << setfill('-') << " " << endl;
			cout << left << setw(20) << setfill(separator) << "Name";
			outfile1 << left << setw(20) << setfill(separator) << "Name";
			cout << left << setw(15) << setfill(separator) << "Account Number";
			outfile1 << left << setw(15) << setfill(separator) << "Account Number";
			cout << left << setw(20) << setfill(separator) << "Transaction Number";
			outfile1 << left << setw(20) << setfill(separator) << "Transaction Number";
			cout << left << setw(40) << setfill(separator) << "Expected Transaction Location";
			outfile1 << left << setw(40) << setfill(separator) << "Expected Transaction Location";
			cout << left << setw(15) << setfill(separator) << "Actual Transaction Location" << endl;
			outfile1 << left << setw(15) << setfill(separator) << "Actual Transaction Location" << endl;
			while ((row = mysql_fetch_row(res))!=NULL)
			{
				cout << left << setw(20) << setfill(separator) << row[0];
				outfile1 << left << setw(20) << setfill(separator) << row[0];
				cout << left << setw(15) << setfill(separator) << row[1];
				outfile1 << left << setw(15) << setfill(separator) << row[1];
				cout << left << setw(20) << setfill(separator) << row[2];
				outfile1 << left << setw(20) << setfill(separator) << row[2];
				cout << left << setw(40) << setfill(separator) << row[6];
				outfile1 << left << setw(40) << setfill(separator) << row[6];
				cout << left << setw(15) << setfill(separator) << row[5] << endl;
				outfile1 << left << setw(15) << setfill(separator) << row[5] << endl;
			}
		
		}
		else
		{
			cout << "Query failed: " << mysql_error(conn) << endl;
		}

		mysql_free_result(res);
		mysql_close(conn1);
	}
	else {
		puts("Connection to database has failed!");
	}
	
	return 0;
}